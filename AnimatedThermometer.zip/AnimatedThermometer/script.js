{/* <span id="temp" class="fa"></span> */}
const tempLoad = () => { //creating a function here
    let temp = document.getElementById('temp');
    temp.innerHTML = "&#xf2cb";
    temp.style.color = "#f8b627"; // yello color version


    setTimeout(() => {
        temp.innerHTML = "&#xf2ca";
    }, 1000);

    setTimeout(() => {
        temp.innerHTML = "&#xf2c9";
    }, 2000);

    setTimeout(() => {
        temp.innerHTML = "&#xf2c8";
    }, 3000);

    setTimeout(() => {
        temp.innerHTML = "&#xf2c7";
        temp.style.color = "#d63031"; //red color version
    }, 4000);
}


tempLoad();
setInterval(tempLoad, 5000); //after 5secs tempLoad function will be countinued 